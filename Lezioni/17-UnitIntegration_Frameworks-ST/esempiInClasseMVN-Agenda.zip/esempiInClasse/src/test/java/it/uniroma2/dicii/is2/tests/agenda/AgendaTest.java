/*
 *    Copyright (C) 2026 Guglielmo De Angelis (a.k.a. Gulyx)
 *    
 *    This file is part of the contents developed for the course
 * 	  IS2 (A.Y. 2025-2026) at Università di Tor Vergata in Rome. 
 *
 *    This is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as 
 *    published by the Free Software Foundation, either version 3 of the 
 *    License, or (at your option) any later version.
 *
 *    This software is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with this source.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package it.uniroma2.dicii.is2.tests.agenda;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.*;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import it.uniroma2.dicii.is2.agenda.SimpleAgenda;
import it.uniroma2.dicii.is2.agenda.impl.MyAgenda;

// @RunWith attaches a runner with the test class to initialize the test data
@RunWith(MockitoJUnitRunner.class)
public class AgendaTest {

	private static final String LABEL = "This is a mock appointment for: ";

	// @InjectMocks annotation is used to create an instance of the class
	// and it injects the mocks that are created with the @Mock annotations
	// into this instance. (Matching is by type)
	@InjectMocks
	SimpleAgenda agenda = new MyAgenda();

	// @Mock annotation is used to create the mock object to be injected
	@Mock
	Map<String, String> mockedAppointments;

	@Before
	public void createMocks() {
		Date d1 = (new GregorianCalendar(120, 4, 15)).getTime();
		Date d2 = (new GregorianCalendar(119, 7, 31)).getTime();

		String key;

		key = d1.toString();
		// add the mocked behavior of for a set of given dates
		when(mockedAppointments.get(key)).thenReturn(LABEL + key);

		key = d2.toString();
		// 1. add the mocked behavior of for a set of given dates.
		// 2. Strict stubbing that requires that all declared stubs are actually used. 
		//    If a declared stub is never user Mockito will throw an UnnecessaryStubbingException.
		//    The statement lenient() relax this requirement, that specific stub can remain uninvoked.
		//    Check the manual. 
		lenient().when(mockedAppointments.get(key)).thenReturn(LABEL + key);

		when(mockedAppointments.size()).thenReturn(2);
	}

	@Test
	public void mockTest() {
		for (String key : mockedAppointments.keySet()) {
			String v = mockedAppointments.get(key);
// Do not worry, we will never reach this line. We are querying the object on 
// method that was not mocked (i.e. keySet).			
			Assert.fail();
		}

		this.mockedAppointments.put("foo", "LABEL");
		int size = mockedAppointments.size();

		Assert.assertEquals(2, size);
	}

	@Test
	public void simpleTest() {
		int appCounter = agenda.getAppointments().size();
// Do not expect that appCounter is 2 (or more in general different than 0) ... 
// we are actually querying an object that was not mocked!!!
// See the details of the implementation of the method: MyAgenda.getAppointments()
		Assert.assertEquals(0, appCounter);
	}

	@Test
	public void anotherSimpleTest() {
		Date dMocked = (new GregorianCalendar(120, 4, 15)).getTime();
		Date dNotMocked = (new GregorianCalendar(0, 1, 1)).getTime();

		String labelMocked = agenda.getAppointment(dMocked);
		String labelNotMocked = agenda.getAppointment(dNotMocked);

		boolean condition = labelMocked.equals(LABEL + dMocked.toString()) && (labelNotMocked == null);
		Assert.assertTrue(condition);
	}

	@Test
	public void verifyTest() {
//	Mockito.verify checks if certain behavior happened once

		boolean verified1 = true;
		boolean verified2 = true;
		boolean verified3 = true;
		boolean verified4 = true;

		Date dMocked = (new GregorianCalendar(120, 4, 15)).getTime();
		Date dNotMocked = (new GregorianCalendar(0, 1, 1)).getTime();

		
		mockedAppointments.put(dMocked.toString(), "appointment");
		
//		Verification on a mock with an assigned value but never used
		try {
			verify(mockedAppointments).get(dMocked.toString());
		} catch (Throwable e) {
			verified1 = false;
		}

//		Verification on a mock with an assigned value used once
		try {
			mockedAppointments.get(dMocked.toString());
			verify(mockedAppointments).get(dMocked.toString());
		} catch (Throwable e) {
			verified2 = false;
		}

//		Verification on a mock with an unassigned value but never used
		try {
			verify(mockedAppointments).get(dNotMocked.toString());
		} catch (Throwable e) {
			verified3 = false;
		}

//		Verification on a mock with an unassigned value used once
		try {
			mockedAppointments.get(dNotMocked.toString());
			verify(mockedAppointments).get(dNotMocked.toString());
		} catch (Throwable e) {
			verified4 = false;
		}

		boolean condition = (!verified1) && (verified2) && (!verified3) && (verified4);
		Assert.assertTrue(condition);
	}
}
