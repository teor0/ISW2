/*
 *    Copyright (C) 2026 Guglielmo De Angelis (a.k.a. Gulyx)
 *    
 *    This file is part of the contents developed for the course
 * 	  IS2 (A.Y. 2025-2026) at Università di Tor Vergata in Rome. 
 *
 *    This is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as 
 *    published by the Free Software Foundation, either version 3 of the 
 *    License, or (at your option) any later version.
 *
 *    This software is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with this source.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package it.uniroma2.dicii.is2.agenda.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import it.uniroma2.dicii.is2.agenda.SimpleAgenda;

public class MyAgenda implements SimpleAgenda {

	private Map<String, String> appointments;
	
	public List<String> getAppointments() {
		List<String> lst = new ArrayList<String>();
		for (String key : this.appointments.keySet()) {
			String label = this.appointments.get(key);
			lst.add(label);
		}

		return lst;
	}

	public String getAppointment(Date d) {
		String dateString = d.toString();
		String app = this.appointments.get(dateString);
		
		return app;
	}

	public void addAppointments(Date d, String label) {
		// TODO Auto-generated method stub
		// this behavior is not implemented yet in this class
	}

}
