/*
 *    Copyright (C) 2022 Guglielmo De Angelis (a.k.a. Gulyx)
 *    
 *    This file is part of the contents developed for the course
 * 	  IS2 (A.Y. 2021-2022) at Università di Tor Vergata in Rome. 
 *
 *    This is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as 
 *    published by the Free Software Foundation, either version 3 of the 
 *    License, or (at your option) any later version.
 *
 *    This software is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with this source.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package it.uniroma2.dicii.is2.trivialExamples;

import it.uniroma2.dicii.is2.exceptions.Exception1;
import it.uniroma2.dicii.is2.exceptions.Exception2;

public class UnreachableCodeSimpleExample {

	private void op1(int i) throws Exception {
		if (i % 2 == 0) {
			Exception1 e = new Exception1();
			throw e;
		}
	}

	private void op2(int i) throws Exception {
		if ((i % 2 != 0)) {
			Exception1 e = new Exception1();
			throw e;
		}
	}

	private void op2(int i, int j) throws Exception {
		if ((i % 2 != 0) && (j > 17)) {
			Exception1 e = new Exception1();
			throw e;
		}
	}

	public void unreachablePaths(int i) {
		try {
			this.op1(i);
			this.op2(i);
		} catch (Exception1 e1) {
			e1.printStackTrace();
		} catch (Exception2 e2) {
// There is no test that can reach the following statement!!!
			e2.printStackTrace();
		} catch (Exception e) {
// There is no test that can reach the following statement!!!	
			e.printStackTrace();
		}

	}

}
